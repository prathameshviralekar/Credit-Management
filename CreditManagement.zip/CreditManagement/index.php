<html>
<head>
    <title>Credit Management</title>
    <link rel="shortcut icon" href="images/cm.png">
    <link rel="stylesheet" href="mystyle.css">
	<style>
	button{
		background-color:#8cbed6;
	}
	body
	{
		text-align:center;
	}
		body{
		background-image:url("images/1.jpg");
		background-position: center;
		background-repeat: no-repeat;
		background-size: cover;
	}
	</style>
</head>
<body >

	<div id="header">
       <br>
       <h1 style=" font-family:Agency FB; font-size: 70px; color:#ff8c00;text-shadow: 2px 2px black;"> Sparks Foundation Internship Project </h1>
       <h2 style=" font-family:Agency FB; font-size: 55px;color:#ff1493;text-shadow: 2px 2px black;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Credit Management </h2>
    </div>
        <div id="section">
            <table>
                <tr></tr>
                <tr><br>
				<a href="getdetail.php">
               <button class="glow-on-hover" type="button" href="getdetail.php">View users</button>
                </a>

               
                </tr>

                <tr>        
               <br> <br> <br>
			   <a href="transfer.php">
			   <button class="glow-on-hover" type="button">Credit Transfer</button>
               </a>
               
               </tr>

            </table>
    </div>
</body>
</html>